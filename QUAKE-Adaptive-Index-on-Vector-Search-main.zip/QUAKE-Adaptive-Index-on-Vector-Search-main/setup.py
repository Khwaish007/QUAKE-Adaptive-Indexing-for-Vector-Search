from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="quake-vector-index",
    version="0.1.0",
    author="Rudrash Borkar",
    author_email="nborkar2005@gmail.com",
    description="QUAKE: Adaptive Partition Scanning and Dynamic Maintenance for Vector Search",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Rudrash42/QUAKE-Adaptive-Index-on-Vector-Search",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.24.0",
        "scipy>=1.10.0",
        "scikit-learn>=1.2.0",
        "matplotlib>=3.7.0",
    ],
    extras_require={
        "faiss": ["faiss-cpu>=1.7.4"],
        "dev": ["pytest>=7.0.0"],
    },
)
