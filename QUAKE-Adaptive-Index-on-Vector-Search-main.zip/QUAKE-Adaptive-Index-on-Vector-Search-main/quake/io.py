"""Vector Dataset I/O and Synthetic Data Generator.

Provides loaders for standard ANN benchmark formats (.fvecs, .ivecs, .bvecs)
and high-fidelity synthetic vector benchmark generators.
"""

from typing import Tuple
import numpy as np


def read_fvecs(filename: str) -> np.ndarray:
    """Read a .fvecs binary file into a NumPy float32 array of shape (N, D).
    
    Format: Each vector begins with a 4-byte int specifying dimension D,
    followed by D 4-byte float32 values.
    
    Args:
        filename: Path to the .fvecs file.
        
    Returns:
        np.ndarray: Array of shape (N, D) and dtype float32.
    """
    data = np.fromfile(filename, dtype=np.float32)
    if data.size == 0:
        return np.empty((0, 0), dtype=np.float32)
    dim = int(data.view(np.int32)[0])
    data = data.reshape(-1, dim + 1)
    return data[:, 1:].copy()


def read_ivecs(filename: str) -> np.ndarray:
    """Read a .ivecs binary file into a NumPy int32 array of shape (N, D).
    
    Format: Each vector begins with a 4-byte int specifying dimension D,
    followed by D 4-byte int32 values (typically ground truth neighbor IDs).
    
    Args:
        filename: Path to the .ivecs file.
        
    Returns:
        np.ndarray: Array of shape (N, D) and dtype int32.
    """
    data = np.fromfile(filename, dtype=np.int32)
    if data.size == 0:
        return np.empty((0, 0), dtype=np.int32)
    dim = int(data[0])
    data = data.reshape(-1, dim + 1)
    return data[:, 1:].copy()


def read_bvecs(filename: str) -> np.ndarray:
    """Read a .bvecs binary file into a NumPy uint8 array of shape (N, D).
    
    Args:
        filename: Path to the .bvecs file.
        
    Returns:
        np.ndarray: Array of shape (N, D) and dtype uint8.
    """
    data = np.fromfile(filename, dtype=np.uint8)
    if data.size == 0:
        return np.empty((0, 0), dtype=np.uint8)
    dim = int(data[:4].view(np.int32)[0])
    row_bytes = dim + 4
    data = data.reshape(-1, row_bytes)
    return data[:, 4:].copy()


def write_fvecs(filename: str, data: np.ndarray) -> None:
    """Write a NumPy array of shape (N, D) to a .fvecs binary file.
    
    Args:
        filename: Destination path.
        data: Array of shape (N, D).
    """
    n, d = data.shape
    dim_header = np.array([d], dtype=np.int32)
    with open(filename, "wb") as f:
        for i in range(n):
            dim_header.tofile(f)
            data[i].astype(np.float32).tofile(f)


def write_ivecs(filename: str, data: np.ndarray) -> None:
    """Write a NumPy array of shape (N, D) to a .ivecs binary file.
    
    Args:
        filename: Destination path.
        data: Array of shape (N, D).
    """
    n, d = data.shape
    dim_header = np.array([d], dtype=np.int32)
    with open(filename, "wb") as f:
        for i in range(n):
            dim_header.tofile(f)
            data[i].astype(np.int32).tofile(f)


def generate_synthetic_dataset(
    num_base: int = 10000,
    num_queries: int = 1000,
    dim: int = 128,
    k: int = 100,
    num_clusters: int = 20,
    metric: str = "L2",
    seed: int = 42,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Generate clustered synthetic vector dataset with exact ground truth.
    
    Creates a realistic mixture of Gaussian vector clusters to accurately simulate
    real-world vector embedding distributions.
    
    Args:
        num_base: Number of base vectors (database size).
        num_queries: Number of query vectors.
        dim: Dimensionality of vectors.
        k: Top-k groundtruth nearest neighbors to compute.
        num_clusters: Number of latent Gaussian clusters.
        metric: Distance metric ('L2' or 'cosine'/'IP').
        seed: Random seed for reproducibility.
        
    Returns:
        Tuple containing:
        - base_vectors: Array of shape (num_base, dim)
        - query_vectors: Array of shape (num_queries, dim)
        - groundtruth_indices: Array of shape (num_queries, k) with exact nearest neighbor indices
    """
    rng = np.random.RandomState(seed)

    # 1. Generate cluster centers
    cluster_centers = rng.randn(num_clusters, dim).astype(np.float32)
    cluster_centers /= np.linalg.norm(cluster_centers, axis=1, keepdims=True)

    # 2. Sample base points around cluster centers
    base_points = []
    points_per_cluster = num_base // num_clusters
    for i in range(num_clusters):
        count = points_per_cluster if i < num_clusters - 1 else num_base - (points_per_cluster * (num_clusters - 1))
        pts = cluster_centers[i] + 0.2 * rng.randn(count, dim).astype(np.float32)
        base_points.append(pts)

    base = np.vstack(base_points).astype(np.float32)
    base /= np.linalg.norm(base, axis=1, keepdims=True)

    # 3. Generate query points (some on-cluster, some uniform noise)
    query_points = []
    for _ in range(num_queries):
        if rng.rand() < 0.8:
            cid = rng.randint(0, num_clusters)
            q = cluster_centers[cid] + 0.25 * rng.randn(dim).astype(np.float32)
        else:
            q = rng.randn(dim).astype(np.float32)
        query_points.append(q)

    queries = np.vstack(query_points).astype(np.float32)
    queries /= np.linalg.norm(queries, axis=1, keepdims=True)

    # 4. Compute exact brute-force ground truth
    gt_indices = np.empty((num_queries, k), dtype=np.int32)
    for i in range(num_queries):
        q = queries[i]
        if metric.lower() in ("cosine", "ip", "inner_product"):
            sims = np.dot(base, q)
            top_k = np.argsort(sims)[-k:][::-1]
        else:
            dists = np.linalg.norm(base - q, axis=1)
            top_k = np.argsort(dists)[:k]
        gt_indices[i] = top_k

    return base, queries, gt_indices
