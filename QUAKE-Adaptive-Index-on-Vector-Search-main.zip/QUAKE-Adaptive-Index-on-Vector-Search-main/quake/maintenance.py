"""Dynamic Index Maintenance Engine for QUAKE Vector Index.

Implements online latency model fitting, partition scanning cost estimation,
and cost-driven split & merge operations to dynamically rebalance the index.
"""

from typing import List, Tuple
import time
import numpy as np
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression

from quake.distance import l2_normalize, compute_distances


def measure_cluster_latency(cluster: np.ndarray, sample_queries: np.ndarray, repeats: int = 3, metric: str = "L2") -> float:
    """Measure average wall-clock latency to scan all vectors in a partition.
    
    Args:
        cluster: Array of shape (n_points, d) representing the cluster vectors.
        sample_queries: Array of shape (n_queries, d) sample query vectors.
        repeats: Repetitions per query for timing accuracy.
        metric: Distance metric ('L2' or 'cosine'/'IP').
        
    Returns:
        float: Average scan latency in seconds (or -1.0 if empty).
    """
    size = len(cluster)
    if size == 0:
        return -1.0

    total_time = 0.0
    count = 0
    for q in sample_queries:
        q_norm = l2_normalize(q)
        for _ in range(repeats):
            start = time.perf_counter()
            _ = compute_distances(q_norm, cluster, metric=metric)
            end = time.perf_counter()
            total_time += (end - start)
            count += 1

    return total_time / max(count, 1)


def measure_centroid_overhead(
    centroids: np.ndarray,
    sample_queries: np.ndarray,
    nprobe: int = 5,
    repeats: int = 10,
    metric: str = "L2",
) -> float:
    """Measure average time taken to scan all coarse centroids for a query (Oc).
    
    Args:
        centroids: Array of shape (K, d).
        sample_queries: Array of sample queries.
        nprobe: Number of top centroids to select.
        repeats: Timing repetitions.
        metric: Distance metric.
        
    Returns:
        float: Average centroid overhead in seconds.
    """
    total_time = 0.0
    count = 0
    subset = sample_queries[: min(50, len(sample_queries))]

    for q in subset:
        q_norm = l2_normalize(q)
        for _ in range(repeats):
            start = time.perf_counter()
            dists = compute_distances(q_norm, centroids, metric=metric)
            if metric.lower() in ("cosine", "ip", "inner_product"):
                _ = np.argsort(dists)[-nprobe:]
            else:
                _ = np.argsort(dists)[:nprobe]
            end = time.perf_counter()
            total_time += (end - start)
            count += 1

    return total_time / max(count, 1)


def fit_latency_model(
    clusters: List[np.ndarray],
    sample_queries: np.ndarray,
    metric: str = "L2",
) -> Tuple[float, float]:
    """Fit a linear regression model predicting partition scan latency from partition size.
    
    Model:
        Latency(S_i) = w * S_i + b
    
    Args:
        clusters: List of partition vector arrays.
        sample_queries: Sample queries used for benchmarking.
        metric: Distance metric.
        
    Returns:
        Tuple of (latency_w, latency_bias).
    """
    latencies = []
    sizes = []

    queries_norm = l2_normalize(sample_queries[: min(10, len(sample_queries))])

    for cluster in clusters:
        if len(cluster) < 2:
            continue
        lat = measure_cluster_latency(cluster, queries_norm, repeats=2, metric=metric)
        if lat > 0:
            latencies.append(lat)
            sizes.append(len(cluster))

    if len(sizes) < 2:
        # Default fallback reasonable coefficients for CPU vector distance scanning
        return 1.2e-7, 1e-6

    X_sizes = np.array(sizes, dtype=np.float64).reshape(-1, 1)
    y_latencies = np.array(latencies, dtype=np.float64).reshape(-1, 1)

    reg = LinearRegression().fit(X_sizes, y_latencies)
    latency_w = float(reg.coef_[0][0] if hasattr(reg.coef_[0], "__len__") else reg.coef_[0])
    latency_bias = float(reg.intercept_[0] if hasattr(reg.intercept_, "__len__") else reg.intercept_)

    # Ensure non-negative slope
    latency_w = max(latency_w, 1e-9)
    latency_bias = max(latency_bias, 0.0)

    return latency_w, latency_bias


def compute_partition_cost(
    cluster_size: int,
    access_count: float,
    num_centroids: int,
    latency_w: float,
    latency_bias: float,
    Oc: float,
    total_accesses: float,
) -> float:
    """Compute estimated query cost contribution of a partition under the QUAKE cost model.
    
    Cost formula:
        Cost(C_i) = Oc + (A_i / sum(A)) * Latency(S_i)
        where Latency(S_i) = latency_w * S_i + latency_bias
    
    Args:
        cluster_size: Number of vectors in partition (|C_i|).
        access_count: Historical query access count for partition (A_i).
        num_centroids: Current total number of coarse centroids.
        latency_w: Linear latency slope coefficient.
        latency_bias: Latency intercept.
        Oc: Centroid scanning overhead.
        total_accesses: Total query accesses across all partitions.
        
    Returns:
        float: Estimated cost value.
    """
    if cluster_size == 0:
        return float("inf")

    access_freq = access_count / total_accesses if total_accesses > 0 else 0.0
    latency = latency_w * cluster_size + latency_bias
    return Oc + access_freq * latency


def split_partition(clusters: List[np.ndarray], idx: int) -> Tuple[np.ndarray, np.ndarray]:
    """Split partition at index `idx` into two sub-partitions using 2-means clustering.
    
    Args:
        clusters: List of partition arrays (modified in-place).
        idx: Index of partition to split.
        
    Returns:
        Tuple of (sub_cluster_0, sub_cluster_1).
    """
    points = clusters[idx]
    if len(points) < 2:
        return points, np.empty((0, points.shape[1]), dtype=points.dtype)

    kmeans = KMeans(n_clusters=2, random_state=42, n_init=5, verbose=0).fit(points)
    c0 = points[kmeans.labels_ == 0]
    c1 = points[kmeans.labels_ == 1]

    clusters[idx] = c0
    clusters.insert(idx + 1, c1)
    return c0, c1


def merge_partitions(clusters: List[np.ndarray], i: int, j: int) -> np.ndarray:
    """Merge partition at index `j` into partition at index `i`.
    
    Args:
        clusters: List of partition arrays (modified in-place).
        i: Target partition index.
        j: Source partition index to merge into i and remove.
        
    Returns:
        np.ndarray: Merged vector array.
    """
    merged = np.vstack((clusters[i], clusters[j]))
    clusters[i] = merged
    del clusters[j]
    return merged


def run_maintenance_pass(
    clusters: List[np.ndarray],
    centroids: np.ndarray,
    access_counts: np.ndarray,
    latency_w: float,
    latency_bias: float,
    Oc: float,
    alpha: float = 0.9,
    tau: float = 0.0,
    verbose: bool = False,
) -> Tuple[List[np.ndarray], np.ndarray, np.ndarray, int, int]:
    """Execute a complete dynamic maintenance pass across all partitions.
    
    Evaluates split and merge opportunities against the predictive cost model:
    - Split Candidate: If Cost(C_0) + Cost(C_1) < Cost(C_i) - tau, partition is split.
    - Merge Candidate: If Cost(C_i U C_j) < Cost(C_i) + Cost(C_j) - tau, partitions are merged.
    
    Args:
        clusters: List of cluster point arrays.
        centroids: Centroid matrix of shape (K, d).
        access_counts: Access count array of shape (K,).
        latency_w: Latency slope.
        latency_bias: Latency intercept.
        Oc: Centroid overhead.
        alpha: Access count inheritance factor for splits (default: 0.9).
        tau: Cost reduction threshold for taking maintenance action (default: 0.0).
        verbose: If True, prints split and merge events.
        
    Returns:
        Tuple containing:
        - updated clusters list
        - updated centroids array
        - updated access_counts array
        - number of splits performed
        - number of merges performed
    """
    total_accesses = np.sum(access_counts)
    num_splits = 0
    num_merges = 0

    if total_accesses == 0:
        return clusters, centroids, access_counts, 0, 0

    i = 0
    while i < len(clusters):
        size = len(clusters[i])
        Ai = access_counts[i]
        Ci = compute_partition_cost(
            size, Ai, len(centroids), latency_w, latency_bias, Oc, total_accesses
        )

        # -------------------------------------------------------------
        # 1. SPLIT CANDIDATE EVALUATION
        # -------------------------------------------------------------
        if len(clusters[i]) >= 4:
            kmeans = KMeans(n_clusters=2, random_state=42, n_init=5, verbose=0).fit(clusters[i])
            c0 = clusters[i][kmeans.labels_ == 0]
            c1 = clusters[i][kmeans.labels_ == 1]

            if len(c0) > 0 and len(c1) > 0:
                a0 = alpha * Ai
                a1 = alpha * Ai
                C0 = compute_partition_cost(
                    len(c0), a0, len(centroids) + 1, latency_w, latency_bias, Oc, total_accesses
                )
                C1 = compute_partition_cost(
                    len(c1), a1, len(centroids) + 1, latency_w, latency_bias, Oc, total_accesses
                )

                if (C0 + C1) < Ci - tau:
                    split_partition(clusters, i)
                    centroids[i] = c0.mean(axis=0)
                    centroids = np.insert(centroids, i + 1, c1.mean(axis=0), axis=0)
                    access_counts[i] = int(a0)
                    access_counts = np.insert(access_counts, i + 1, int(a1))
                    num_splits += 1
                    if verbose:
                        print(f"  [Maintenance] Split cluster {i} (sizes: {len(c0)}, {len(c1)})")
                    i += 2
                    continue

        # -------------------------------------------------------------
        # 2. MERGE CANDIDATE EVALUATION
        # -------------------------------------------------------------
        if i + 1 < len(clusters):
            j = i + 1
            sj = len(clusters[j])
            Aj = access_counts[j]
            Cj = compute_partition_cost(
                sj, Aj, len(centroids), latency_w, latency_bias, Oc, total_accesses
            )

            old_merge_cost = Ci + Cj
            merged_size = size + sj
            a_merged = Ai + Aj
            C_merged = compute_partition_cost(
                merged_size, a_merged, len(centroids) - 1, latency_w, latency_bias, Oc, total_accesses
            )

            if C_merged < old_merge_cost - tau:
                merge_partitions(clusters, i, j)
                centroids[i] = clusters[i].mean(axis=0)
                centroids = np.delete(centroids, j, axis=0)
                access_counts[i] = access_counts[i] + access_counts[j]
                access_counts = np.delete(access_counts, j)
                num_merges += 1
                if verbose:
                    print(f"  [Maintenance] Merged clusters {i} and {j} (new size: {merged_size})")
                continue

        i += 1

    return clusters, centroids, access_counts, num_splits, num_merges
