"""QUAKE Adaptive Vector Index Class.

Provides an intuitive, high-performance scikit-learn / FAISS style interface
unifying Adaptive Partition Scanning (APS), online latency modeling, multi-threaded
query execution, vectorized batching, and cost-driven dynamic maintenance.
"""

from concurrent.futures import ThreadPoolExecutor
import threading
import time
from typing import Dict, List, Optional, Tuple, Union
import numpy as np
from sklearn.cluster import KMeans

from quake.aps import scan_partitions_adaptive
from quake.distance import compute_distances, compute_pairwise_distances, l2_normalize
from quake.maintenance import fit_latency_model, measure_centroid_overhead, run_maintenance_pass


class QuakeIndex:
    """Adaptive Vector Index (QUAKE).
    
    Attributes:
        num_clusters (int): Initial number of coarse clusters.
        metric (str): Distance metric ('L2' or 'cosine'/'IP').
        alpha (float): Balance weight between geometric distance and historical access ratio.
        prob_threshold (float): Probability threshold for adaptive partition scanning.
        maintenance_interval (int): Queries between automatic dynamic maintenance runs.
        random_state (int): Seed for cluster initialization.
    """

    def __init__(
        self,
        num_clusters: int = 100,
        metric: str = "L2",
        alpha: float = 0.90,
        prob_threshold: float = 0.10,
        maintenance_interval: Optional[int] = 500,
        random_state: int = 42,
    ):
        self.initial_num_clusters = num_clusters
        self.metric = metric
        self.alpha = alpha
        self.prob_threshold = prob_threshold
        self.maintenance_interval = maintenance_interval
        self.random_state = random_state

        # Index state
        self.centroids: Optional[np.ndarray] = None
        self.clusters: List[np.ndarray] = []
        self.access_counts: Optional[np.ndarray] = None
        self.dim: int = 0
        self.total_vectors: int = 0

        # Maintenance model state
        self.latency_w: float = 1e-7
        self.latency_bias: float = 1e-6
        self.Oc: float = 1e-5
        self.queries_processed: int = 0
        self.maintenance_runs: int = 0

        # Concurrency
        self._lock = threading.Lock()

    @property
    def num_clusters(self) -> int:
        """Current number of active clusters."""
        return len(self.clusters)

    @property
    def cluster_sizes(self) -> List[int]:
        """List of vector counts in each active cluster."""
        return [len(c) for c in self.clusters]

    def fit(self, vectors: np.ndarray, sample_queries: Optional[np.ndarray] = None) -> "QuakeIndex":
        """Build coarse clusters and calibrate online latency model.
        
        Args:
            vectors: Matrix of shape (N, D) database vectors.
            sample_queries: Optional sample queries for calibrating the latency model.
            
        Returns:
            self
        """
        X = l2_normalize(vectors) if self.metric.lower() in ("l2", "cosine", "ip") else vectors
        self.total_vectors = len(X)
        self.dim = X.shape[1]

        k_clusters = min(self.initial_num_clusters, self.total_vectors)
        kmeans = KMeans(
            n_clusters=k_clusters,
            random_state=self.random_state,
            n_init=5,
            verbose=0,
        ).fit(X)

        self.centroids = kmeans.cluster_centers_.copy()
        self.clusters = [X[kmeans.labels_ == i].copy() for i in range(k_clusters)]
        self.access_counts = np.zeros(k_clusters, dtype=np.int64)

        # Calibrate latency model & centroid overhead
        calib_queries = sample_queries if sample_queries is not None else X[: min(100, len(X))]
        self.latency_w, self.latency_bias = fit_latency_model(
            self.clusters, calib_queries, metric=self.metric
        )
        self.Oc = measure_centroid_overhead(
            self.centroids, calib_queries, nprobe=max(1, int(np.sqrt(k_clusters))), metric=self.metric
        )

        return self

    def add(self, vectors: np.ndarray) -> None:
        """Dynamically add new vectors to existing index partitions.
        
        Args:
            vectors: Array of shape (M, D) vectors to insert.
        """
        if self.centroids is None:
            raise ValueError("Index not fitted. Call fit() before adding vectors.")

        X = l2_normalize(vectors) if self.metric.lower() in ("l2", "cosine", "ip") else vectors
        pairwise_dists = compute_pairwise_distances(X, self.centroids, metric=self.metric)

        if self.metric.lower() in ("cosine", "ip", "inner_product"):
            nearest_cluster_indices = np.argmax(pairwise_dists, axis=1)
        else:
            nearest_cluster_indices = np.argmin(pairwise_dists, axis=1)

        with self._lock:
            for vec_idx, cid in enumerate(nearest_cluster_indices):
                if len(self.clusters[cid]) == 0:
                    self.clusters[cid] = X[vec_idx : vec_idx + 1]
                else:
                    self.clusters[cid] = np.vstack((self.clusters[cid], X[vec_idx]))
            self.total_vectors += len(X)

    def search_single(
        self,
        query: np.ndarray,
        k: int = 100,
        prob_threshold: Optional[float] = None,
        update_access: bool = True,
    ) -> Tuple[np.ndarray, int, np.ndarray]:
        """Search top-k neighbors for a single query vector.
        
        Args:
            query: Query vector of shape (D,).
            k: Top-k neighbors to return.
            prob_threshold: Probability threshold override (default: self.prob_threshold).
            update_access: Whether to update historical access frequency.
            
        Returns:
            Tuple of (neighbors_array, scanned_partitions_count, partition_probabilities).
        """
        threshold = prob_threshold if prob_threshold is not None else self.prob_threshold
        neighbors, scanned_count, probs, scanned_indices = scan_partitions_adaptive(
            query=query,
            centroids=self.centroids,
            clusters=self.clusters,
            access_counts=self.access_counts,
            k=k,
            prob_threshold=threshold,
            alpha=self.alpha,
            metric=self.metric,
        )

        if update_access:
            with self._lock:
                self.access_counts[scanned_indices] += 1
                self.queries_processed += 1

        return neighbors, scanned_count, probs

    def search(
        self,
        queries: np.ndarray,
        k: int = 100,
        prob_threshold: Optional[float] = None,
        mode: str = "threaded",
        num_threads: int = 6,
        auto_maintain: bool = True,
    ) -> List[np.ndarray]:
        """Batch query search using threaded or vectorized execution.
        
        Args:
            queries: Array of shape (Q, D).
            k: Top-k neighbors per query.
            prob_threshold: Probability threshold override.
            mode: 'threaded', 'vectorized', or 'sequential'.
            num_threads: Number of worker threads for 'threaded' mode.
            auto_maintain: Whether to trigger periodic dynamic maintenance.
            
        Returns:
            List of length Q, each containing (k, D) retrieved neighbor vectors.
        """
        if self.centroids is None or len(self.clusters) == 0:
            raise ValueError("Index is empty or not fitted.")

        threshold = prob_threshold if prob_threshold is not None else self.prob_threshold
        n_queries = len(queries)
        results: List[Optional[np.ndarray]] = [None] * n_queries

        if mode == "threaded":
            with ThreadPoolExecutor(max_workers=num_threads) as executor:
                futures = [
                    executor.submit(
                        self._threaded_worker,
                        i,
                        queries[i],
                        k,
                        threshold,
                    )
                    for i in range(n_queries)
                ]
                for future in futures:
                    idx, neighbors = future.result()
                    results[idx] = neighbors

        elif mode == "vectorized":
            # Vectorized batch processing
            results = self._search_vectorized(queries, k=k, prob_threshold=threshold)

        else:  # Sequential
            for i in range(n_queries):
                neighbors, _, _ = self.search_single(queries[i], k=k, prob_threshold=threshold, update_access=True)
                results[i] = neighbors

        # Automatic maintenance check
        if auto_maintain and self.maintenance_interval and self.maintenance_interval > 0:
            if self.queries_processed >= self.maintenance_interval * (self.maintenance_runs + 1):
                self.maintain()

        return [r if r is not None else np.empty((0, self.dim), dtype=np.float32) for r in results]

    def _threaded_worker(
        self,
        query_idx: int,
        query: np.ndarray,
        k: int,
        prob_threshold: float,
    ) -> Tuple[int, np.ndarray]:
        neighbors, _, _, scanned_indices = scan_partitions_adaptive(
            query=query,
            centroids=self.centroids,
            clusters=self.clusters,
            access_counts=self.access_counts,
            k=k,
            prob_threshold=prob_threshold,
            alpha=self.alpha,
            metric=self.metric,
        )
        with self._lock:
            self.access_counts[scanned_indices] += 1
            self.queries_processed += 1

        return query_idx, neighbors

    def _search_vectorized(
        self,
        queries: np.ndarray,
        k: int = 100,
        prob_threshold: float = 0.1,
    ) -> List[np.ndarray]:
        """Vectorized batch query search across centroids."""
        queries_norm = l2_normalize(queries) if self.metric.lower() in ("l2", "cosine", "ip") else queries
        all_dists = compute_pairwise_distances(queries_norm, self.centroids, metric=self.metric)

        total_accesses = np.sum(self.access_counts) + 1e-10
        access_ratios = self.access_counts / total_accesses

        results = []
        for i, q in enumerate(queries_norm):
            dists = all_dists[i]
            # Vectorized prob calculation
            if self.metric.lower() in ("cosine", "ip", "inner_product"):
                dist_exp = np.exp(dists - np.max(dists))
            else:
                dist_exp = np.exp(-dists)
            p_dist = dist_exp / (np.sum(dist_exp) + 1e-10)
            p_access = np.sqrt(access_ratios + 1e-12)
            probs = self.alpha * p_dist + (1.0 - self.alpha) * p_access

            high_prob_indices = np.where(probs > prob_threshold)[0]
            if len(high_prob_indices) == 0:
                if self.metric.lower() in ("cosine", "ip", "inner_product"):
                    high_prob_indices = np.argsort(dists)[-int(np.sqrt(self.num_clusters)):]
                else:
                    high_prob_indices = np.argsort(dists)[:int(np.sqrt(self.num_clusters))]

            with self._lock:
                self.access_counts[high_prob_indices] += 1
                self.queries_processed += 1

            candidates = [self.clusters[idx] for idx in high_prob_indices if len(self.clusters[idx]) > 0]
            if candidates:
                cand_matrix = np.vstack(candidates)
                cand_dists = compute_distances(q, cand_matrix, metric=self.metric)
                top_k = min(k, len(cand_matrix))
                if self.metric.lower() in ("cosine", "ip", "inner_product"):
                    nearest = np.argsort(cand_dists)[-top_k:][::-1]
                else:
                    nearest = np.argsort(cand_dists)[:top_k]
                results.append(cand_matrix[nearest])
            else:
                results.append(np.empty((0, self.dim), dtype=np.float32))

        return results

    def maintain(self, tau: float = 0.0, verbose: bool = False) -> Dict[str, Union[int, float]]:
        """Run cost-driven dynamic split & merge maintenance pass.
        
        Args:
            tau: Cost reduction threshold for splits/merges.
            verbose: Whether to log maintenance actions.
            
        Returns:
            Dict containing maintenance statistics.
        """
        with self._lock:
            start_time = time.perf_counter()
            self.clusters, self.centroids, self.access_counts, num_splits, num_merges = run_maintenance_pass(
                clusters=self.clusters,
                centroids=self.centroids,
                access_counts=self.access_counts,
                latency_w=self.latency_w,
                latency_bias=self.latency_bias,
                Oc=self.Oc,
                alpha=self.alpha,
                tau=tau,
                verbose=verbose,
            )
            duration = time.perf_counter() - start_time
            self.maintenance_runs += 1

        return {
            "splits": num_splits,
            "merges": num_merges,
            "num_clusters_after": self.num_clusters,
            "duration_s": duration,
        }
