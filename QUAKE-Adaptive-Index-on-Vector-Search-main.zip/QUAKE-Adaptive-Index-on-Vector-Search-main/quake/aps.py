"""Adaptive Partition Scanning (APS) Engine for QUAKE Vector Index.

Implements probability-based cluster selection combining geometric proximity
and empirical cluster access frequency.
"""

from typing import List, Optional, Tuple
import numpy as np

from quake.distance import compute_distances, l2_normalize


def compute_partition_probability(
    distance_to_centroid: float,
    all_distances: np.ndarray,
    access_ratio: float,
    alpha: float = 0.90,
    metric: str = "L2",
) -> float:
    """Compute the probability that a cluster contains a k-NN for the query.
    
    Combines two signals:
    1. Distance component (geometric proximity): Softmax over negative distances (or positive cosine)
    2. Access component (workload skew prior): Square root of historical access ratio
    
    Probability formulation:
        P(C_i | q) = min(1.0, alpha * P_dist(C_i, q) + (1 - alpha) * P_access(C_i))
    
    Args:
        distance_to_centroid: Distance or similarity from query to this centroid.
        all_distances: Distances or similarities from query to all centroids.
        access_ratio: Historical access fraction A_i / sum(A).
        alpha: Weight for distance vs access frequency (default: 0.90).
        metric: 'L2' or 'cosine'/'IP'.
        
    Returns:
        float: Probability in [0, 1].
    """
    metric_lower = metric.lower()
    if metric_lower in ("cosine", "ip", "inner_product"):
        # Higher inner product = closer
        dist_exp = np.exp(distance_to_centroid)
        dist_exp_all = np.exp(np.array(all_distances))
    else:
        # Lower Euclidean distance = closer
        dist_exp = np.exp(-distance_to_centroid)
        dist_exp_all = np.exp(-np.array(all_distances))

    p_dist = dist_exp / (np.sum(dist_exp_all) + 1e-10)
    p_access = np.sqrt(access_ratio + 1e-12)

    prob = alpha * p_dist + (1.0 - alpha) * p_access
    return float(min(1.0, prob))


def compute_all_partition_probabilities(
    centroid_dists: np.ndarray,
    access_ratios: np.ndarray,
    alpha: float = 0.90,
    metric: str = "L2",
) -> np.ndarray:
    """Vectorized computation of partition probabilities across all clusters.
    
    Args:
        centroid_dists: Array of shape (K,) with distances to all centroids.
        access_ratios: Array of shape (K,) with access frequencies.
        alpha: Weight for distance component (default: 0.90).
        metric: 'L2' or 'cosine'/'IP'.
        
    Returns:
        Array of shape (K,) with probabilities in [0, 1].
    """
    metric_lower = metric.lower()
    if metric_lower in ("cosine", "ip", "inner_product"):
        dist_exp = np.exp(centroid_dists - np.max(centroid_dists))  # Numerical stability
    else:
        dist_exp = np.exp(-centroid_dists)

    p_dist = dist_exp / (np.sum(dist_exp) + 1e-10)
    p_access = np.sqrt(access_ratios + 1e-12)

    probabilities = alpha * p_dist + (1.0 - alpha) * p_access
    return np.clip(probabilities, 0.0, 1.0)


def scan_partitions_adaptive(
    query: np.ndarray,
    centroids: np.ndarray,
    clusters: List[np.ndarray],
    access_counts: np.ndarray,
    k: int = 100,
    prob_threshold: float = 0.1,
    alpha: float = 0.90,
    metric: str = "L2",
) -> Tuple[np.ndarray, int, np.ndarray, np.ndarray]:
    """Execute adaptive query search against partitioned vector index.
    
    Workflow:
    1. Compute query-centroid distances.
    2. Compute partition probabilities combining distance & workload access priors.
    3. Select all partitions where P(C_i | q) > prob_threshold.
    4. Fall back to top-sqrt(K) nearest centroids if no partition passes threshold.
    5. Aggregate candidate vectors from selected partitions.
    6. Extract top-k nearest neighbors via exact distance sorting.
    
    Args:
        query: Query vector of shape (d,).
        centroids: Centroids matrix of shape (K, d).
        clusters: List of K NumPy arrays containing vectors for each partition.
        access_counts: Access count array of shape (K,).
        k: Number of nearest neighbors to retrieve.
        prob_threshold: Probability threshold for partition scanning (default: 0.1).
        alpha: Balance weight between geometric distance and access frequency (default: 0.90).
        metric: 'L2' or 'cosine'/'IP'.
        
    Returns:
        Tuple containing:
        - neighbors: Array of shape (min(k, n_candidates), d) of retrieved vectors.
        - scanned_count: Number of partitions scanned.
        - probabilities: Array of shape (K,) with computed probabilities.
        - scanned_indices: Indices of partitions that were scanned.
    """
    K = len(clusters)
    dim = centroids.shape[1]
    query_norm = l2_normalize(query) if metric.lower() in ("l2", "cosine", "ip") else query

    # Step 1: Distance to centroids
    centroid_dists = compute_distances(query_norm, centroids, metric=metric)

    # Step 2: Access ratio priors
    total_accesses = np.sum(access_counts) + 1e-10
    access_ratios = access_counts / total_accesses

    # Step 3: Compute probabilities
    probabilities = compute_all_partition_probabilities(
        centroid_dists, access_ratios, alpha=alpha, metric=metric
    )

    # Step 4: Identify high-probability clusters
    high_prob_indices = np.where(probabilities > prob_threshold)[0]

    # Fallback to sqrt(K) if no clusters passed threshold
    if len(high_prob_indices) == 0:
        if metric.lower() in ("cosine", "ip", "inner_product"):
            high_prob_indices = np.argsort(centroid_dists)[-int(np.sqrt(K)):]
        else:
            high_prob_indices = np.argsort(centroid_dists)[:int(np.sqrt(K))]

    scanned_count = len(high_prob_indices)

    # Step 5: Gather candidate points from chosen partitions
    candidate_list = []
    for idx in high_prob_indices:
        if idx < len(clusters) and len(clusters[idx]) > 0:
            candidate_list.append(clusters[idx])

    if not candidate_list:
        return np.empty((0, dim), dtype=np.float32), scanned_count, probabilities, high_prob_indices

    candidate_points = np.vstack(candidate_list)
    if len(candidate_points) == 0:
        return np.empty((0, dim), dtype=np.float32), scanned_count, probabilities, high_prob_indices

    # Step 6: Rank candidate points
    candidate_dists = compute_distances(query_norm, candidate_points, metric=metric)
    top_k = min(k, len(candidate_points))

    if metric.lower() in ("cosine", "ip", "inner_product"):
        nearest_indices = np.argsort(candidate_dists)[-top_k:][::-1]
    else:  # L2 distance
        nearest_indices = np.argsort(candidate_dists)[:top_k]

    neighbors = candidate_points[nearest_indices]
    return neighbors, scanned_count, probabilities, high_prob_indices
