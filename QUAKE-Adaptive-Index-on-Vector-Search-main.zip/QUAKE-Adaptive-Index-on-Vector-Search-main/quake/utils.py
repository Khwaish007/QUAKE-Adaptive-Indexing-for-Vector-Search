"""Evaluation metrics and benchmark helpers for Vector Search."""

from typing import Callable, Dict, List, Sequence, Set, Tuple, Union
import time
import numpy as np

from quake.distance import l2_normalize


def compute_recall_at_k(
    predicted_neighbors: np.ndarray,
    groundtruth_indices: np.ndarray,
    base_vectors: np.ndarray,
    k: int = 100,
) -> float:
    """Compute recall@k for a single query using vector values or indices.
    
    Args:
        predicted_neighbors: Retrieved vectors of shape (M, D) (M >= k).
        groundtruth_indices: Array of shape (K,) with true neighbor indices in base_vectors.
        base_vectors: Base vector dataset of shape (N, D).
        k: Number of neighbors to evaluate.
        
    Returns:
        float: Recall score between 0.0 and 1.0.
    """
    if len(predicted_neighbors) == 0 or len(groundtruth_indices) == 0:
        return 0.0

    gt_k_indices = groundtruth_indices[:k]
    gt_vecs = l2_normalize(base_vectors[gt_k_indices])
    pred_vecs = l2_normalize(predicted_neighbors[:k])

    gt_set = set(map(tuple, np.round(gt_vecs, decimals=5)))
    pred_set = set(map(tuple, np.round(pred_vecs, decimals=5)))

    intersection = len(gt_set & pred_set)
    return float(intersection / max(len(gt_set), 1))


def compute_recall_from_indices(
    predicted_indices: Sequence[int],
    groundtruth_indices: Sequence[int],
    k: int = 100,
) -> float:
    """Compute index-based recall@k.
    
    Args:
        predicted_indices: Array/list of retrieved vector indices.
        groundtruth_indices: Array/list of ground truth vector indices.
        k: Number of top neighbors.
        
    Returns:
        float: Recall in [0, 1].
    """
    pred_set = set(predicted_indices[:k])
    gt_set = set(groundtruth_indices[:k])
    if not gt_set:
        return 0.0
    return float(len(pred_set & gt_set) / len(gt_set))


def evaluate_batch_recall(
    batch_predictions: List[np.ndarray],
    batch_gt_indices: np.ndarray,
    base_vectors: np.ndarray,
    k: int = 100,
) -> Tuple[float, List[float]]:
    """Compute average recall and per-query recall list for a batch of predictions.
    
    Args:
        batch_predictions: List of retrieved neighbor matrices for each query.
        batch_gt_indices: 2D array of shape (batch_size, gt_k).
        base_vectors: Database vectors array.
        k: Recall cutoff.
        
    Returns:
        Tuple of (mean_recall, list_of_individual_recalls).
    """
    recalls = []
    for pred, gt in zip(batch_predictions, batch_gt_indices):
        rec = compute_recall_at_k(pred, gt, base_vectors, k=k)
        recalls.append(rec)

    mean_rec = float(np.mean(recalls)) if recalls else 0.0
    return mean_rec, recalls


def benchmark_search_throughput(
    search_fn: Callable[[np.ndarray], List[np.ndarray]],
    queries: np.ndarray,
    warmup_count: int = 50,
) -> Dict[str, float]:
    """Benchmark query throughput (QPS) and latency statistics.
    
    Args:
        search_fn: Callable taking a query batch and returning results.
        queries: Array of queries of shape (N, D).
        warmup_count: Number of queries for warmup.
        
    Returns:
        Dict with total_time, qps, latency_p50_ms, latency_p95_ms, latency_p99_ms.
    """
    # Warmup
    if warmup_count > 0 and len(queries) >= warmup_count:
        _ = search_fn(queries[:warmup_count])

    start_time = time.perf_counter()
    results = search_fn(queries)
    total_time = time.perf_counter() - start_time

    n_queries = len(queries)
    qps = n_queries / max(total_time, 1e-9)

    return {
        "num_queries": n_queries,
        "total_time_s": total_time,
        "qps": qps,
        "avg_latency_ms": (total_time / n_queries) * 1000.0,
    }
