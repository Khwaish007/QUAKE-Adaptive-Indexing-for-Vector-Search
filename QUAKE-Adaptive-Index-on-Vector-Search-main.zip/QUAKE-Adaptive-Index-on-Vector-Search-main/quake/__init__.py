"""QUAKE: Adaptive Indexing for Vector Search.

An adaptive vector indexing library implementing Adaptive Partition Scanning (APS),
cost-driven dynamic cluster maintenance (split & merge), and multi-level hierarchical IVF.
"""

from quake.aps import compute_all_partition_probabilities, compute_partition_probability, scan_partitions_adaptive
from quake.distance import compute_distances, compute_pairwise_distances, l2_normalize
from quake.index import QuakeIndex
from quake.io import generate_synthetic_dataset, read_bvecs, read_fvecs, read_ivecs, write_fvecs, write_ivecs
from quake.maintenance import compute_partition_cost, fit_latency_model, measure_centroid_overhead, measure_cluster_latency, run_maintenance_pass
from quake.multilevel import IVFLevel, MultiLevelIVF
from quake.utils import benchmark_search_throughput, compute_recall_at_k, compute_recall_from_indices, evaluate_batch_recall

__version__ = "0.1.0"
__all__ = [
    "QuakeIndex",
    "MultiLevelIVF",
    "IVFLevel",
    "compute_partition_probability",
    "compute_all_partition_probabilities",
    "scan_partitions_adaptive",
    "fit_latency_model",
    "measure_centroid_overhead",
    "measure_cluster_latency",
    "compute_partition_cost",
    "run_maintenance_pass",
    "l2_normalize",
    "compute_distances",
    "compute_pairwise_distances",
    "read_fvecs",
    "read_ivecs",
    "read_bvecs",
    "write_fvecs",
    "write_ivecs",
    "generate_synthetic_dataset",
    "compute_recall_at_k",
    "compute_recall_from_indices",
    "evaluate_batch_recall",
    "benchmark_search_throughput",
]
