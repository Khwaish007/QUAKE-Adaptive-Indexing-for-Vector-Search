"""Multi-Level Hierarchical Inverted File Index (MultiLevelIVF).

Implements multi-tier coarse quantization for high-throughput hierarchical routing
in massive scale vector collections as described in the QUAKE architecture.
"""

from typing import List, Optional
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import normalize

from quake.distance import compute_distances, l2_normalize


class IVFLevel:
    """Node representing a level in the multi-tier IVF index hierarchy."""

    def __init__(self, level: int, centroids: Optional[np.ndarray] = None):
        self.level: int = level
        self.centroids: Optional[np.ndarray] = centroids
        self.children: List["IVFLevel"] = []
        self.vectors: Optional[np.ndarray] = None  # Populated only at leaf level (level=0)

    @property
    def is_leaf(self) -> bool:
        return len(self.children) == 0 and self.vectors is not None


class MultiLevelIVF:
    """Hierarchical Multi-Level Inverted File Index.
    
    Structures coarse centroids into a hierarchical search tree, reducing centroid
    comparison latency from O(K) to O(L * K^(1/L)) for large cluster counts.
    """

    def __init__(
        self,
        num_clusters_per_level: int = 10,
        levels: int = 2,
        metric: str = "L2",
        random_state: int = 42,
    ):
        self.num_clusters_per_level = num_clusters_per_level
        self.levels = levels
        self.metric = metric
        self.random_state = random_state
        self.root: Optional[IVFLevel] = None

    def fit(self, X: np.ndarray) -> "MultiLevelIVF":
        """Build the multi-level hierarchical IVF index.
        
        Args:
            X: Matrix of vector embeddings of shape (N, D).
            
        Returns:
            self
        """
        X_norm = l2_normalize(X)
        self.root = self._build_recursive(X_norm, level=self.levels - 1)
        return self

    def _build_recursive(self, vectors: np.ndarray, level: int) -> IVFLevel:
        node = IVFLevel(level=level)

        if level == 0:
            # Base level: partition raw vectors
            n_clusters = min(self.num_clusters_per_level, len(vectors))
            if n_clusters <= 1:
                node.centroids = vectors.mean(axis=0, keepdims=True)
                leaf = IVFLevel(level=0)
                leaf.vectors = vectors
                node.children.append(leaf)
                return node

            kmeans = KMeans(
                n_clusters=n_clusters,
                random_state=self.random_state,
                n_init=5,
                verbose=0,
            ).fit(vectors)
            node.centroids = kmeans.cluster_centers_

            for cid in range(n_clusters):
                leaf = IVFLevel(level=0)
                leaf.vectors = vectors[kmeans.labels_ == cid]
                node.children.append(leaf)
            return node

        else:
            # Higher level: cluster lower-level centroids
            lower = self._build_recursive(vectors, level=level - 1)
            lower_centroids = lower.centroids

            n_clusters = min(self.num_clusters_per_level, len(lower_centroids))
            if n_clusters <= 1:
                node.centroids = lower_centroids.mean(axis=0, keepdims=True)
                node.children.append(lower)
                return node

            kmeans = KMeans(
                n_clusters=n_clusters,
                random_state=self.random_state,
                n_init=5,
                verbose=0,
            ).fit(lower_centroids)
            node.centroids = kmeans.cluster_centers_

            for cid in range(n_clusters):
                mask = kmeans.labels_ == cid
                grouped_centroids = lower_centroids[mask]

                child = IVFLevel(level=level - 1, centroids=grouped_centroids)
                child.children = [lower.children[idx] for idx in np.where(mask)[0]]
                node.children.append(child)

            return node

    def search(self, query: np.ndarray, k: int = 100, nprobe: int = 2) -> np.ndarray:
        """Search top-k neighbors traversing the multi-level hierarchy.
        
        Args:
            query: Query vector (D,).
            k: Number of nearest neighbors.
            nprobe: Number of top branches to explore at each hierarchy level.
            
        Returns:
            np.ndarray: Top-k nearest neighbor vectors.
        """
        if self.root is None:
            raise ValueError("Index has not been fitted yet. Call fit() first.")

        query_norm = l2_normalize(query)
        candidate_leaves = self._traverse_hierarchy(self.root, query_norm, nprobe=nprobe)

        candidate_vectors = []
        for leaf in candidate_leaves:
            if leaf.vectors is not None and len(leaf.vectors) > 0:
                candidate_vectors.append(leaf.vectors)

        if not candidate_vectors:
            return np.empty((0, query.shape[0]), dtype=np.float32)

        all_candidates = np.vstack(candidate_vectors)
        dists = compute_distances(query_norm, all_candidates, metric=self.metric)

        top_k = min(k, len(all_candidates))
        if self.metric.lower() in ("cosine", "ip", "inner_product"):
            nearest_indices = np.argsort(dists)[-top_k:][::-1]
        else:
            nearest_indices = np.argsort(dists)[:top_k]

        return all_candidates[nearest_indices]

    def _traverse_hierarchy(self, node: IVFLevel, query: np.ndarray, nprobe: int) -> List[IVFLevel]:
        if node.is_leaf or not node.children:
            return [node]

        if node.centroids is None or len(node.centroids) == 0:
            leaves = []
            for child in node.children:
                leaves.extend(self._traverse_hierarchy(child, query, nprobe))
            return leaves

        dists = compute_distances(query, node.centroids, metric=self.metric)
        k_probe = min(nprobe, len(node.centroids))

        if self.metric.lower() in ("cosine", "ip", "inner_product"):
            top_branches = np.argsort(dists)[-k_probe:]
        else:
            top_branches = np.argsort(dists)[:k_probe]

        leaves = []
        for branch_idx in top_branches:
            if branch_idx < len(node.children):
                leaves.extend(self._traverse_hierarchy(node.children[branch_idx], query, nprobe))

        return leaves
