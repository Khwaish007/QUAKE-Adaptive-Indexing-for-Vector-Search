"""Distance and similarity computation utilities for Vector Search."""

import numpy as np


def l2_normalize(vectors: np.ndarray, eps: float = 1e-10) -> np.ndarray:
    """Normalize vectors along the last axis using L2 norm.
    
    Args:
        vectors: Array of shape (d,) or (n, d).
        eps: Small epsilon to prevent division by zero.
        
    Returns:
        L2-normalized vector array of the same shape.
    """
    if vectors.ndim == 1:
        norm = np.linalg.norm(vectors) + eps
        return vectors / norm
    norm = np.linalg.norm(vectors, axis=-1, keepdims=True) + eps
    return vectors / norm


def compute_distances(query: np.ndarray, candidates: np.ndarray, metric: str = "L2") -> np.ndarray:
    """Compute distance/dissimilarity between a single query and candidate points.
    
    For L2: Returns Euclidean distance (lower = more similar).
    For cosine/IP: Returns inner product (higher = more similar).
    
    Args:
        query: Query vector of shape (d,).
        candidates: Candidate matrix of shape (n, d).
        metric: 'L2' for Euclidean distance, 'cosine' or 'IP' for Inner Product.
        
    Returns:
        Array of shape (n,) containing distances or similarity scores.
    """
    if len(candidates) == 0:
        return np.empty((0,), dtype=np.float32)

    metric_lower = metric.lower()
    if metric_lower in ("cosine", "ip", "inner_product"):
        # Inner product on normalized vectors
        return np.dot(candidates, query)
    else:  # Euclidean (L2)
        return np.linalg.norm(candidates - query, axis=1)


def compute_pairwise_distances(queries: np.ndarray, centroids: np.ndarray, metric: str = "L2") -> np.ndarray:
    """Compute pairwise distance matrix between multiple queries and centroids.
    
    Args:
        queries: Array of shape (n_queries, d).
        centroids: Array of shape (n_centroids, d).
        metric: 'L2' or 'cosine'/'IP'.
        
    Returns:
        Distance matrix of shape (n_queries, n_centroids).
    """
    metric_lower = metric.lower()
    if metric_lower in ("cosine", "ip", "inner_product"):
        return np.dot(queries, centroids.T)
    else:  # L2 distance
        # Vectorized Euclidean distance using broadcasting
        # queries: (Q, 1, D), centroids: (1, K, D)
        return np.linalg.norm(queries[:, np.newaxis, :] - centroids[np.newaxis, :, :], axis=2)
