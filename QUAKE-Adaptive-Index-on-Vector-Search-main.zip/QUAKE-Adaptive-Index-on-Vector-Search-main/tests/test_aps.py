"""Unit tests for Adaptive Partition Scanning (APS)."""

import numpy as np
import pytest
from quake.aps import compute_all_partition_probabilities, compute_partition_probability, scan_partitions_adaptive


def test_compute_partition_probability():
    dist = 0.5
    all_dists = np.array([0.5, 1.0, 2.0])
    access_ratio = 0.5
    prob = compute_partition_probability(dist, all_dists, access_ratio, alpha=0.9)
    assert 0.0 <= prob <= 1.0


def test_compute_all_partition_probabilities():
    dists = np.array([0.1, 1.5, 3.0])
    ratios = np.array([0.8, 0.1, 0.1])
    probs = compute_all_partition_probabilities(dists, ratios, alpha=0.85)
    assert len(probs) == 3
    assert np.all(probs >= 0.0)
    assert np.all(probs <= 1.0)
    # The closest and most accessed cluster should have the highest probability
    assert probs[0] > probs[1] > probs[2]


def test_scan_partitions_adaptive():
    centroids = np.array([[1.0, 0.0], [0.0, 1.0], [-1.0, 0.0]], dtype=np.float32)
    clusters = [
        np.array([[1.0, 0.1], [0.9, -0.1], [1.1, 0.0]], dtype=np.float32),
        np.array([[0.1, 1.0], [-0.1, 0.9]], dtype=np.float32),
        np.array([[-1.0, 0.0]], dtype=np.float32),
    ]
    access_counts = np.array([10, 5, 1], dtype=np.int64)
    query = np.array([1.0, 0.0], dtype=np.float32)

    neighbors, scanned_count, probs, scanned_indices = scan_partitions_adaptive(
        query=query,
        centroids=centroids,
        clusters=clusters,
        access_counts=access_counts,
        k=2,
        prob_threshold=0.1,
    )

    assert len(neighbors) == 2
    assert scanned_count >= 1
    assert 0 in scanned_indices
    # Closest vector should be close to [1.0, 0.0]
    assert np.linalg.norm(neighbors[0] - query) < 0.2
