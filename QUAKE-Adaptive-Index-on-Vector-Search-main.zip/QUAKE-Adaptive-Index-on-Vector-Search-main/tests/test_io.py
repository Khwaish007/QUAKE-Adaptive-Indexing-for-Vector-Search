"""Unit tests for dataset I/O and synthetic data generation."""

import os
import tempfile
import numpy as np
import pytest
from quake.io import (
    generate_synthetic_dataset,
    read_bvecs,
    read_fvecs,
    read_ivecs,
    write_fvecs,
    write_ivecs,
)


def test_synthetic_data_generation():
    base, queries, gt = generate_synthetic_dataset(
        num_base=200, num_queries=20, dim=16, k=10, num_clusters=5, seed=123
    )
    assert base.shape == (200, 16)
    assert queries.shape == (20, 16)
    assert gt.shape == (20, 10)
    assert gt.dtype == np.int32


def test_fvecs_io():
    data = np.random.randn(50, 16).astype(np.float32)
    with tempfile.NamedTemporaryFile(suffix=".fvecs", delete=False) as f:
        path = f.name

    try:
        write_fvecs(path, data)
        loaded = read_fvecs(path)
        assert np.allclose(data, loaded)
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_ivecs_io():
    data = np.random.randint(0, 1000, size=(50, 10), dtype=np.int32)
    with tempfile.NamedTemporaryFile(suffix=".ivecs", delete=False) as f:
        path = f.name

    try:
        write_ivecs(path, data)
        loaded = read_ivecs(path)
        assert np.array_equal(data, loaded)
    finally:
        if os.path.exists(path):
            os.remove(path)
