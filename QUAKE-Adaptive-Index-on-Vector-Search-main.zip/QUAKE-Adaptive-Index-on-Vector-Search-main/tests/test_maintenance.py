"""Unit tests for Dynamic Index Maintenance (Split / Merge / Cost)."""

import numpy as np
import pytest
from quake.maintenance import (
    compute_partition_cost,
    fit_latency_model,
    merge_partitions,
    run_maintenance_pass,
    split_partition,
)


def test_cost_function():
    # Larger size or higher access frequency should increase cost
    c_small = compute_partition_cost(
        cluster_size=10, access_count=5, num_centroids=10,
        latency_w=1e-5, latency_bias=1e-6, Oc=1e-5, total_accesses=100
    )
    c_large = compute_partition_cost(
        cluster_size=1000, access_count=5, num_centroids=10,
        latency_w=1e-5, latency_bias=1e-6, Oc=1e-5, total_accesses=100
    )
    assert c_large > c_small


def test_split_partition():
    cluster = np.array([
        [0.0, 0.0], [0.1, 0.1], [0.05, -0.05],
        [10.0, 10.0], [10.1, 10.2], [9.9, 9.8]
    ], dtype=np.float32)
    clusters = [cluster]

    c0, c1 = split_partition(clusters, 0)
    assert len(clusters) == 2
    assert len(c0) + len(c1) == len(cluster)
    assert len(c0) > 0 and len(c1) > 0


def test_merge_partitions():
    c0 = np.array([[1.0, 1.0], [1.1, 1.1]], dtype=np.float32)
    c1 = np.array([[2.0, 2.0], [2.1, 2.1]], dtype=np.float32)
    clusters = [c0, c1]

    merged = merge_partitions(clusters, 0, 1)
    assert len(clusters) == 1
    assert len(merged) == 4
    assert len(clusters[0]) == 4


def test_run_maintenance_pass():
    clusters = [
        np.random.randn(50, 4).astype(np.float32),
        np.random.randn(2, 4).astype(np.float32),
        np.random.randn(2, 4).astype(np.float32),
    ]
    centroids = np.array([c.mean(axis=0) for c in clusters])
    access_counts = np.array([100, 1, 1], dtype=np.int64)

    clusters_out, centroids_out, counts_out, splits, merges = run_maintenance_pass(
        clusters=clusters,
        centroids=centroids,
        access_counts=access_counts,
        latency_w=1e-4,
        latency_bias=1e-5,
        Oc=1e-6,
        tau=0.0,
    )
    assert len(clusters_out) == len(centroids_out) == len(counts_out)
