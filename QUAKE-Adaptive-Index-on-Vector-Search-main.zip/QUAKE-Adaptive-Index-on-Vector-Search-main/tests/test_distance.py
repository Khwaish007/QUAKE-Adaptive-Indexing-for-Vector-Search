"""Unit tests for distance and normalization routines."""

import numpy as np
import pytest
from quake.distance import compute_distances, compute_pairwise_distances, l2_normalize


def test_l2_normalize():
    vec = np.array([3.0, 4.0], dtype=np.float32)
    norm_vec = l2_normalize(vec)
    assert np.isclose(np.linalg.norm(norm_vec), 1.0)
    assert np.allclose(norm_vec, [0.6, 0.8])

    mat = np.array([[1.0, 1.0], [0.0, 5.0]], dtype=np.float32)
    norm_mat = l2_normalize(mat)
    assert np.allclose(np.linalg.norm(norm_mat, axis=1), [1.0, 1.0])


def test_compute_distances_l2():
    q = np.array([0.0, 0.0], dtype=np.float32)
    pts = np.array([[3.0, 4.0], [1.0, 0.0]], dtype=np.float32)
    dists = compute_distances(q, pts, metric="L2")
    assert np.allclose(dists, [5.0, 1.0])


def test_compute_distances_cosine():
    q = np.array([1.0, 0.0], dtype=np.float32)
    pts = np.array([[1.0, 0.0], [0.0, 1.0], [-1.0, 0.0]], dtype=np.float32)
    sims = compute_distances(q, pts, metric="cosine")
    assert np.allclose(sims, [1.0, 0.0, -1.0])


def test_compute_pairwise_distances():
    queries = np.array([[0.0, 0.0], [1.0, 1.0]], dtype=np.float32)
    centroids = np.array([[0.0, 0.0], [1.0, 1.0], [2.0, 2.0]], dtype=np.float32)
    dist_matrix = compute_pairwise_distances(queries, centroids, metric="L2")
    assert dist_matrix.shape == (2, 3)
    assert np.isclose(dist_matrix[0, 0], 0.0)
    assert np.isclose(dist_matrix[1, 1], 0.0)
