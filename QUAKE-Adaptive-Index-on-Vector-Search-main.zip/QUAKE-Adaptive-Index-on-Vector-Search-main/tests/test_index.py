"""End-to-end integration tests for QuakeIndex."""

import numpy as np
import pytest
from quake.index import QuakeIndex
from quake.io import generate_synthetic_dataset
from quake.utils import compute_recall_at_k


def test_quake_index_fit_and_search():
    base, queries, gt = generate_synthetic_dataset(
        num_base=500, num_queries=50, dim=16, k=10, num_clusters=5, seed=42
    )

    index = QuakeIndex(num_clusters=5, metric="L2", prob_threshold=0.1)
    index.fit(base)

    assert index.num_clusters == 5
    assert index.total_vectors == 500

    # Test single search
    neighbors, scanned_count, probs = index.search_single(queries[0], k=10)
    assert len(neighbors) == 10
    assert scanned_count >= 1

    # Test threaded batch search
    results_threaded = index.search(queries, k=10, mode="threaded", num_threads=2)
    assert len(results_threaded) == len(queries)
    for res in results_threaded:
        assert len(res) == 10

    # Test vectorized batch search
    results_vec = index.search(queries, k=10, mode="vectorized")
    assert len(results_vec) == len(queries)

    # Check that recall is high
    recalls = [compute_recall_at_k(res, gt[i], base, k=10) for i, res in enumerate(results_threaded)]
    assert np.mean(recalls) > 0.80


def test_quake_index_dynamic_maintenance():
    base, queries, gt = generate_synthetic_dataset(
        num_base=400, num_queries=100, dim=16, k=5, num_clusters=4, seed=42
    )

    index = QuakeIndex(num_clusters=4, metric="L2", maintenance_interval=50)
    index.fit(base)

    # Skew accesses heavily to one cluster
    index.access_counts[0] = 500
    m_res = index.maintain(tau=0.0)

    assert "splits" in m_res
    assert "merges" in m_res
    assert index.num_clusters == len(index.clusters)


def test_quake_index_add():
    base, queries, _ = generate_synthetic_dataset(
        num_base=100, num_queries=10, dim=8, k=5, num_clusters=2, seed=42
    )
    index = QuakeIndex(num_clusters=2, metric="L2")
    index.fit(base)

    new_vecs = np.random.randn(20, 8).astype(np.float32)
    index.add(new_vecs)
    assert index.total_vectors == 120
