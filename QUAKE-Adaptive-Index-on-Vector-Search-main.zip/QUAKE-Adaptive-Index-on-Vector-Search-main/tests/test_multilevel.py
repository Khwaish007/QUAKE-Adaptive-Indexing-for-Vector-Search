"""Unit tests for MultiLevelIVF hierarchical index."""

import numpy as np
import pytest
from quake.multilevel import MultiLevelIVF


def test_multilevel_ivf_build_and_search():
    X = np.random.randn(200, 16).astype(np.float32)
    query = np.random.randn(16).astype(np.float32)

    ivf = MultiLevelIVF(num_clusters_per_level=3, levels=2, metric="L2")
    ivf.fit(X)

    assert ivf.root is not None
    assert ivf.root.level == 1
    assert len(ivf.root.children) > 0

    results = ivf.search(query, k=5, nprobe=2)
    assert len(results) == 5
    assert results.shape[1] == 16
