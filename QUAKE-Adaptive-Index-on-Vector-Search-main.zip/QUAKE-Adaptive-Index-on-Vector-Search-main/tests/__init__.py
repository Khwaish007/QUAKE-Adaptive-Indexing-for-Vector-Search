# Test suite for QUAKE vector index
