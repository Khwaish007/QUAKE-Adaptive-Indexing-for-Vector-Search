"""Helper script to download and extract standard vector search benchmarks (SIFT1M, GIST1M)."""

import argparse
import os
import tarfile
import urllib.request


DATASET_URLS = {
    "sift": "ftp://ftp.irisa.fr/local/texmex/corpus/sift.tar.gz",
    "gist": "ftp://ftp.irisa.fr/local/texmex/corpus/gist.tar.gz",
}

HTTP_FALLBACK_URLS = {
    "sift": "http://corpus-texmex.irisa.fr/sift.tar.gz",
    "gist": "http://corpus-texmex.irisa.fr/gist.tar.gz",
}


def download_and_extract(dataset_name: str, target_dir: str) -> None:
    os.makedirs(target_dir, exist_ok=True)
    dataset_key = dataset_name.lower()

    if dataset_key not in DATASET_URLS:
        print(f"Unknown dataset: {dataset_name}. Choose 'sift' or 'gist'.")
        return

    tar_path = os.path.join(target_dir, f"{dataset_key}.tar.gz")
    url = DATASET_URLS[dataset_key]

    print(f"Downloading {dataset_name.upper()} from {url}...")
    try:
        urllib.request.urlretrieve(url, tar_path)
    except Exception as e:
        print(f"FTP download failed ({e}), attempting HTTP fallback: {HTTP_FALLBACK_URLS[dataset_key]}...")
        urllib.request.urlretrieve(HTTP_FALLBACK_URLS[dataset_key], tar_path)

    print(f"Extracting {tar_path}...")
    with tarfile.open(tar_path, "r:gz") as tar:
        tar.extractall(path=target_dir)

    print(f"Dataset {dataset_name.upper()} successfully extracted to {target_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Download SIFT/GIST vector benchmarks.")
    parser.add_argument(
        "--dataset",
        choices=["sift", "gist", "all"],
        default="sift",
        help="Dataset to download (default: sift)",
    )
    parser.add_argument(
        "--dest",
        default="./data",
        help="Destination directory (default: ./data)",
    )
    args = parser.parse_args()

    if args.dataset == "all":
        download_and_extract("sift", args.dest)
        download_and_extract("gist", args.dest)
    else:
        download_and_extract(args.dataset, args.dest)
