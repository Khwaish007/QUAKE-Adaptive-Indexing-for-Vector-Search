"""Comprehensive SIFT1M Benchmark for QUAKE Adaptive Index.

Evaluates Adaptive Partition Scanning (APS) vs Fixed nprobe, dynamically adjusts
partitions via cost-driven maintenance (split/merge), and tracks recall and throughput.
"""

import argparse
import copy
import math
import os
import sys
import time
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import normalize

from quake.aps import scan_partitions_adaptive
from quake.distance import compute_distances, l2_normalize
from quake.io import generate_synthetic_dataset, read_fvecs, read_ivecs
from quake.maintenance import fit_latency_model, measure_centroid_overhead, run_maintenance_pass
from quake.utils import compute_recall_at_k


def run_sift_benchmark(
    data_dir: str = ".",
    num_queries: int = 1000,
    batch_size: int = 500,
    num_threads: int = 6,
    prob_threshold: float = 0.1,
    alpha: float = 0.90,
    save_plot: bool = True,
    plot_path: str = "benchmarks/results/aps_recall_over_batches.png",
):
    base_file = os.path.join(data_dir, "sift_base.fvecs")
    query_file = os.path.join(data_dir, "sift_query.fvecs")
    gt_file = os.path.join(data_dir, "sift_groundtruth.ivecs")

    if os.path.exists(base_file) and os.path.exists(query_file) and os.path.exists(gt_file):
        print("Loading SIFT dataset from files...")
        base = read_fvecs(base_file)
        queries = read_fvecs(query_file)
        gt = read_ivecs(gt_file)
    else:
        print(f"SIFT dataset not found in {data_dir}. Generating synthetic benchmark dataset (10,000 vectors, 128D)...")
        base, queries, gt = generate_synthetic_dataset(
            num_base=10000, num_queries=num_queries, dim=128, k=100, num_clusters=50, seed=42
        )

    print(f"Dataset summary: Base {base.shape}, Queries {queries.shape}, Ground Truth {gt.shape}")

    # Normalize vectors
    print("Normalizing base and query vectors...")
    X = l2_normalize(base)
    Q = l2_normalize(queries[:num_queries])

    num_clusters = 100
    print(f"Initializing {num_clusters} coarse clusters via K-Means...")
    kmeans = KMeans(n_clusters=num_clusters, random_state=42, n_init=5, verbose=0).fit(X)
    centroids = kmeans.cluster_centers_.copy()

    clusters = [X[kmeans.labels_ == cid].copy() for cid in range(num_clusters)]
    print(f"Created {len(clusters)} partitions. Sizes: min={min(len(c) for c in clusters)}, max={max(len(c) for c in clusters)}")

    # Calibrate latency model
    print("Fitting latency model & measuring centroid overhead...")
    latency_w, latency_bias = fit_latency_model(clusters, Q[:50])
    Oc = measure_centroid_overhead(centroids, Q[:50])
    print(f"Latency model: Latency(S) = {latency_w:.4e} * S + {latency_bias:.4e}, Oc = {Oc:.4e}s")

    # =========================================================================
    # APS EVALUATION WITH DYNAMIC MAINTENANCE
    # =========================================================================
    print("\n" + "=" * 70)
    print(f"RUNNING APS BENCHMARK (Threshold={prob_threshold}, Threads={num_threads})")
    print("=" * 70)

    from concurrent.futures import ThreadPoolExecutor
    import threading

    clusters_aps = [c.copy() for c in clusters]
    centroids_aps = centroids.copy()
    access_counts_aps = np.zeros(len(clusters_aps), dtype=np.int64)
    access_lock = threading.Lock()

    recalls_aps = []
    scanned_counts_aps = []
    batch_recalls_history = []
    batch_labels = []

    def aps_worker(q_idx, query_vec):
        neighbors, scanned, probs, scanned_indices = scan_partitions_adaptive(
            query=query_vec,
            centroids=centroids_aps,
            clusters=clusters_aps,
            access_counts=access_counts_aps,
            k=100,
            prob_threshold=prob_threshold,
            alpha=alpha,
            metric="L2",
        )
        with access_lock:
            access_counts_aps[scanned_indices] += 1
        return q_idx, neighbors, scanned

    start_time = time.perf_counter()
    num_batches = (num_queries + batch_size - 1) // batch_size

    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        for b in range(num_batches):
            b_start = b * batch_size
            b_end = min((b + 1) * batch_size, num_queries)
            batch_q = Q[b_start:b_end]

            futures = [executor.submit(aps_worker, idx, batch_q[local_i]) for local_i, idx in enumerate(range(b_start, b_end))]

            batch_recalls = []
            for f in futures:
                q_idx, neighbors, scanned = f.result()
                scanned_counts_aps.append(scanned)
                if len(neighbors) > 0:
                    rec = compute_recall_at_k(neighbors, gt[q_idx], X, k=100)
                    recalls_aps.append(rec)
                    batch_recalls.append(rec)

            avg_b_recall = np.mean(batch_recalls) if batch_recalls else 0.0
            batch_recalls_history.append(avg_b_recall)
            batch_labels.append(f"B{b+1}\n({len(clusters_aps)}c)")
            print(f"Batch {b+1}/{num_batches}: Queries [{b_start}:{b_end}], Recall@100 = {avg_b_recall:.4f}, Active Clusters = {len(clusters_aps)}")

            # Trigger maintenance between batches
            if b < num_batches - 1:
                clusters_aps, centroids_aps, access_counts_aps, splits, merges = run_maintenance_pass(
                    clusters=clusters_aps,
                    centroids=centroids_aps,
                    access_counts=access_counts_aps,
                    latency_w=latency_w,
                    latency_bias=latency_bias,
                    Oc=Oc,
                    alpha=alpha,
                    tau=0.0,
                    verbose=True,
                )
                print(f"  --> Maintenance pass {b+1}: Splits={splits}, Merges={merges}, Total Clusters={len(clusters_aps)}")

    total_time = time.perf_counter() - start_time
    mean_recall = np.mean(recalls_aps)
    qps = num_queries / total_time
    avg_scanned = np.mean(scanned_counts_aps)

    print("\n" + "-" * 70)
    print("APS SUMMARY:")
    print(f"  Total Time:          {total_time:.3f}s")
    print(f"  Throughput (QPS):    {qps:.1f} queries/sec")
    print(f"  Mean Recall@100:     {mean_recall:.4f}")
    print(f"  Avg Clusters Scanned:{avg_scanned:.1f} / {len(clusters_aps)} ({avg_scanned/len(clusters_aps)*100:.1f}%)")
    print("-" * 70)

    # Save recall progression plot
    if save_plot and len(batch_recalls_history) > 1:
        os.makedirs(os.path.dirname(plot_path), exist_ok=True)
        plt.figure(figsize=(10, 5))
        plt.plot(range(1, len(batch_recalls_history) + 1), batch_recalls_history, marker="o", linewidth=2.5, color="#1f77b4", label="APS Adaptive Index")
        plt.title("APS Recall@100 Progression Across Batches with Online Dynamic Maintenance", fontsize=12, fontweight="bold")
        plt.xlabel("Batch Index", fontsize=11)
        plt.ylabel("Recall@100", fontsize=11)
        plt.xticks(range(1, len(batch_recalls_history) + 1), batch_labels)
        plt.grid(True, linestyle="--", alpha=0.6)
        plt.ylim(0, 1.05)
        plt.legend(fontsize=11)
        plt.tight_layout()
        plt.savefig(plot_path, dpi=150)
        plt.close()
        print(f"Saved recall progression plot to {plot_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run SIFT1M APS benchmark.")
    parser.add_argument("--data-dir", default=".", help="Directory containing sift dataset files")
    parser.add_argument("--queries", type=int, default=1000, help="Number of queries to benchmark")
    parser.add_argument("--batch-size", type=int, default=500, help="Batch size between maintenance passes")
    parser.add_argument("--threads", type=int, default=6, help="Worker threads")
    parser.add_argument("--prob-threshold", type=float, default=0.1, help="APS probability threshold")
    args = parser.parse_args()

    run_sift_benchmark(
        data_dir=args.data_dir,
        num_queries=args.queries,
        batch_size=args.batch_size,
        num_threads=args.threads,
        prob_threshold=args.prob_threshold,
    )
