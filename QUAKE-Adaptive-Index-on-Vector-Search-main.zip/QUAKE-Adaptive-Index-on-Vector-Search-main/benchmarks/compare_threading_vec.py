"""Benchmark: Multi-Threaded Worker Execution vs Vectorized NumPy Batching.

Evaluates throughput (QPS), latency, and recall stability across batches with
online maintenance in QUAKE.
"""

import argparse
import copy
import math
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import normalize

from quake.aps import scan_partitions_adaptive
from quake.distance import compute_distances, compute_pairwise_distances, l2_normalize
from quake.io import generate_synthetic_dataset, read_fvecs, read_ivecs
from quake.maintenance import fit_latency_model, measure_centroid_overhead, run_maintenance_pass
from quake.utils import compute_recall_at_k


def run_throughput_comparison(
    data_dir: str = ".",
    num_queries: int = 1000,
    batch_size: int = 100,
    num_threads: int = 6,
    k: int = 100,
    save_plot: bool = True,
    plot_path: str = "benchmarks/results/benchmark_threading_recall_over_batches.png",
):
    print("=" * 80)
    print("BENCHMARK: MULTI-THREADED WORKERS vs VECTORIZED BATCHING")
    print("=" * 80)

    base_file = os.path.join(data_dir, "sift_base.fvecs")
    query_file = os.path.join(data_dir, "sift_query.fvecs")
    gt_file = os.path.join(data_dir, "sift_groundtruth.ivecs")

    if os.path.exists(base_file) and os.path.exists(query_file) and os.path.exists(gt_file):
        base = read_fvecs(base_file)
        queries = read_fvecs(query_file)
        gt = read_ivecs(gt_file)
    else:
        print("Dataset not found. Generating synthetic vectors for throughput benchmark...")
        base, queries, gt = generate_synthetic_dataset(
            num_base=10000, num_queries=num_queries, dim=128, k=k, num_clusters=100, seed=42
        )

    queries = queries[:num_queries]
    X = l2_normalize(base)
    Q = l2_normalize(queries)

    num_clusters = 100
    print(f"Initializing {num_clusters} coarse clusters...")
    kmeans = KMeans(n_clusters=num_clusters, random_state=42, n_init=5, verbose=0).fit(X)
    centroids = kmeans.cluster_centers_.copy()
    clusters = [X[kmeans.labels_ == i].copy() for i in range(num_clusters)]

    latency_w, latency_bias = fit_latency_model(clusters, Q[:50])
    Oc = measure_centroid_overhead(centroids, Q[:50])

    from concurrent.futures import ThreadPoolExecutor
    import threading

    # -------------------------------------------------------------------------
    # TEST 1: THREADING
    # -------------------------------------------------------------------------
    print(f"\n[TEST 1] THREADING ({num_threads} worker threads, batch_size={batch_size})...")
    clusters_t = [c.copy() for c in clusters]
    centroids_t = centroids.copy()
    access_t = np.zeros(len(clusters_t), dtype=np.int64)
    lock = threading.Lock()
    recalls_t = []

    def thread_worker(q_idx, query_vec):
        nprobe = max(1, int(math.sqrt(len(clusters_t))))
        dists = compute_distances(query_vec, centroids_t, metric="L2")
        nearest_c = np.argsort(dists)[:nprobe]
        with lock:
            access_t[nearest_c] += 1
        cand_pts = np.vstack([clusters_t[idx] for idx in nearest_c if len(clusters_t[idx]) > 0])
        cand_dists = compute_distances(query_vec, cand_pts, metric="L2")
        top_k = cand_pts[np.argsort(cand_dists)[:k]]
        return q_idx, top_k

    query_time_t = 0.0
    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        for b_start in range(0, num_queries, batch_size):
            b_end = min(b_start + batch_size, num_queries)
            batch = Q[b_start:b_end]

            t0 = time.perf_counter()
            futures = [executor.submit(thread_worker, b_start + i, batch[i]) for i in range(len(batch))]
            for f in futures:
                q_idx, preds = f.result()
                rec = compute_recall_at_k(preds, gt[q_idx], X, k=k)
                recalls_t.append(rec)
            query_time_t += time.perf_counter() - t0

            if b_end % 500 == 0:
                clusters_t, centroids_t, access_t, _, _ = run_maintenance_pass(
                    clusters_t, centroids_t, access_t, latency_w, latency_bias, Oc
                )

    thread_qps = num_queries / query_time_t
    thread_rec = np.mean(recalls_t)

    # -------------------------------------------------------------------------
    # TEST 2: VECTORIZED BATCHING
    # -------------------------------------------------------------------------
    print(f"\n[TEST 2] VECTORIZED BATCHING (batch_size={batch_size})...")
    clusters_v = [c.copy() for c in clusters]
    centroids_v = centroids.copy()
    access_v = np.zeros(len(clusters_v), dtype=np.int64)
    recalls_v = []

    def vectorized_batch(batch_queries):
        nprobe = max(1, int(math.sqrt(len(clusters_v))))
        all_dists = compute_pairwise_distances(batch_queries, centroids_v, metric="L2")
        nearest_batch = np.argsort(all_dists, axis=1)[:, :nprobe]

        for cid in range(len(clusters_v)):
            access_v[cid] += np.sum((nearest_batch == cid).any(axis=1))

        batch_results = []
        for i in range(len(batch_queries)):
            cand = np.vstack([clusters_v[idx] for idx in nearest_batch[i] if len(clusters_v[idx]) > 0])
            c_dists = compute_distances(batch_queries[i], cand, metric="L2")
            batch_results.append(cand[np.argsort(c_dists)[:k]])
        return batch_results

    query_time_v = 0.0
    for b_start in range(0, num_queries, batch_size):
        b_end = min(b_start + batch_size, num_queries)
        batch = Q[b_start:b_end]

        t0 = time.perf_counter()
        batch_res = vectorized_batch(batch)
        query_time_v += time.perf_counter() - t0

        for i, preds in enumerate(batch_res):
            rec = compute_recall_at_k(preds, gt[b_start + i], X, k=k)
            recalls_v.append(rec)

        if b_end % 500 == 0:
            clusters_v, centroids_v, access_v, _, _ = run_maintenance_pass(
                clusters_v, centroids_v, access_v, latency_w, latency_bias, Oc
            )

    vec_qps = num_queries / query_time_v
    vec_rec = np.mean(recalls_v)

    # Summary
    print("\n" + "=" * 60)
    print("RESULTS COMPARISON:")
    print(f"  Threading:   Time={query_time_t:.3f}s | QPS={thread_qps:.1f} | Recall={thread_rec:.4f}")
    print(f"  Vectorized:  Time={query_time_v:.3f}s | QPS={vec_qps:.1f} | Recall={vec_rec:.4f}")
    speedup = query_time_t / max(query_time_v, 1e-9)
    winner = "Vectorized Batching" if query_time_v < query_time_t else "Multi-Threading"
    print(f"\n  🏆 Winner: {winner} ({speedup:.2f}x relative ratio)")
    print("=" * 60)

    if save_plot:
        os.makedirs(os.path.dirname(plot_path), exist_ok=True)
        plt.figure(figsize=(10, 5))
        plt.plot(recalls_t[:200], label=f"Threading (Avg: {thread_rec:.3f})", alpha=0.8, color="#1f77b4")
        plt.plot(recalls_v[:200], label=f"Vectorized (Avg: {vec_rec:.3f})", alpha=0.8, color="#ff7f0e", linestyle="--")
        plt.title("Threading vs Vectorized Batching Query Recall Stability", fontsize=12, fontweight="bold")
        plt.xlabel("Query Index (Sample)", fontsize=11)
        plt.ylabel("Recall@100", fontsize=11)
        plt.grid(True, linestyle="--", alpha=0.6)
        plt.legend(fontsize=11)
        plt.tight_layout()
        plt.savefig(plot_path, dpi=150)
        plt.close()
        print(f"Saved comparison plot to {plot_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Threading vs Vectorized Batching Benchmark.")
    parser.add_argument("--data-dir", default=".", help="Dataset directory")
    parser.add_argument("--queries", type=int, default=1000, help="Number of queries")
    parser.add_argument("--batch-size", type=int, default=100, help="Batch size")
    parser.add_argument("--threads", type=int, default=6, help="Threads for pool")
    args = parser.parse_args()

    run_throughput_comparison(
        data_dir=args.data_dir,
        num_queries=args.queries,
        batch_size=args.batch_size,
        num_threads=args.threads,
    )
