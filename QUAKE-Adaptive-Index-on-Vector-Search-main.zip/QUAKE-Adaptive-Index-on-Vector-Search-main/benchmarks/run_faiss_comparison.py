"""Head-to-head performance benchmark: QUAKE APS vs FAISS Index Baselines.

Compares Recall@100, Throughput (QPS), and Latency against:
- FAISS Flat (Brute Force Exact Search)
- FAISS IVF (Inverted File Index with fixed nprobe)
- FAISS HNSW (Hierarchical Navigable Small World Graph)
- FAISS PQ (Product Quantization)
- QUAKE APS (Adaptive Partition Scanning with dynamic maintenance)
"""

import argparse
import os
import sys
import time
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np

try:
    import faiss
    HAS_FAISS = True
except ImportError:
    HAS_FAISS = False

from quake.index import QuakeIndex
from quake.io import generate_synthetic_dataset, read_fvecs, read_ivecs
from quake.utils import compute_recall_at_k


def run_faiss_benchmark(
    data_dir: str = ".",
    num_queries: int = 1000,
    k: int = 100,
    num_clusters: int = 100,
):
    print("=" * 80)
    print("FAISS vs QUAKE APS COMPREHENSIVE BENCHMARK")
    print("=" * 80)

    base_file = os.path.join(data_dir, "sift_base.fvecs")
    query_file = os.path.join(data_dir, "sift_query.fvecs")
    gt_file = os.path.join(data_dir, "sift_groundtruth.ivecs")

    if os.path.exists(base_file) and os.path.exists(query_file) and os.path.exists(gt_file):
        print("Loading SIFT dataset...")
        base = read_fvecs(base_file)
        queries = read_fvecs(query_file)
        gt = read_ivecs(gt_file)
    else:
        print("Dataset files not found. Generating synthetic vector benchmark (10k base vectors, 128D)...")
        base, queries, gt = generate_synthetic_dataset(
            num_base=10000, num_queries=num_queries, dim=128, k=k, num_clusters=num_clusters, seed=42
        )

    queries = queries[:num_queries]
    dim = base.shape[1]
    results_table: List[Dict] = []

    # -------------------------------------------------------------------------
    # 1. QUAKE APS INDEX
    # -------------------------------------------------------------------------
    print("\n[1/5] Benchmarking QUAKE APS (Adaptive Index)...")
    quake = QuakeIndex(num_clusters=num_clusters, metric="L2", prob_threshold=0.10, maintenance_interval=500)
    t0 = time.perf_counter()
    quake.fit(base, sample_queries=queries[:50])
    build_time = time.perf_counter() - t0

    t0 = time.perf_counter()
    quake_preds = quake.search(queries, k=k, mode="threaded", num_threads=6)
    search_time = time.perf_counter() - t0

    recalls = [compute_recall_at_k(quake_preds[i], gt[i], base, k=k) for i in range(num_queries)]
    avg_recall = np.mean(recalls)
    qps = num_queries / search_time

    results_table.append({
        "Index Method": "QUAKE APS (Adaptive)",
        "Recall@k": avg_recall,
        "QPS": qps,
        "Avg Latency (ms)": (search_time / num_queries) * 1000.0,
        "Build Time (s)": build_time,
    })
    print(f"  QUAKE APS -> Recall: {avg_recall:.4f}, QPS: {qps:.1f}, Latency: {(search_time/num_queries)*1000:.2f}ms")

    if not HAS_FAISS:
        print("\nNote: FAISS is not installed. To run comparative FAISS baselines, install faiss-cpu.")
        _print_summary(results_table)
        return

    # -------------------------------------------------------------------------
    # 2. FAISS FLAT (Brute Force Exact)
    # -------------------------------------------------------------------------
    print("\n[2/5] Benchmarking FAISS Flat (Exact L2)...")
    index_flat = faiss.IndexFlatL2(dim)
    t0 = time.perf_counter()
    index_flat.add(base)
    build_time = time.perf_counter() - t0

    t0 = time.perf_counter()
    _, flat_I = index_flat.search(queries, k)
    search_time = time.perf_counter() - t0

    flat_recalls = [len(set(flat_I[i][:k]) & set(gt[i][:k])) / k for i in range(num_queries)]
    results_table.append({
        "Index Method": "FAISS Flat (Exact)",
        "Recall@k": np.mean(flat_recalls),
        "QPS": num_queries / search_time,
        "Avg Latency (ms)": (search_time / num_queries) * 1000.0,
        "Build Time (s)": build_time,
    })

    # -------------------------------------------------------------------------
    # 3. FAISS IVF (Fixed nprobe)
    # -------------------------------------------------------------------------
    for nprobe in [5, 10]:
        print(f"\n[3/5] Benchmarking FAISS IVF (nlist={num_clusters}, nprobe={nprobe})...")
        quantizer = faiss.IndexFlatL2(dim)
        index_ivf = faiss.IndexIVFFlat(quantizer, dim, num_clusters)
        t0 = time.perf_counter()
        index_ivf.train(base)
        index_ivf.add(base)
        build_time = time.perf_counter() - t0

        index_ivf.nprobe = nprobe
        t0 = time.perf_counter()
        _, ivf_I = index_ivf.search(queries, k)
        search_time = time.perf_counter() - t0

        ivf_recalls = [len(set(ivf_I[i][:k]) & set(gt[i][:k])) / k for i in range(num_queries)]
        results_table.append({
            "Index Method": f"FAISS IVF (nprobe={nprobe})",
            "Recall@k": np.mean(ivf_recalls),
            "QPS": num_queries / search_time,
            "Avg Latency (ms)": (search_time / num_queries) * 1000.0,
            "Build Time (s)": build_time,
        })

    # -------------------------------------------------------------------------
    # 4. FAISS HNSW
    # -------------------------------------------------------------------------
    print("\n[4/5] Benchmarking FAISS HNSW (M=32, efSearch=64)...")
    index_hnsw = faiss.IndexHNSWFlat(dim, 32)
    t0 = time.perf_counter()
    index_hnsw.add(base)
    build_time = time.perf_counter() - t0

    index_hnsw.hnsw.efSearch = 64
    t0 = time.perf_counter()
    _, hnsw_I = index_hnsw.search(queries, k)
    search_time = time.perf_counter() - t0

    hnsw_recalls = [len(set(hnsw_I[i][:k]) & set(gt[i][:k])) / k for i in range(num_queries)]
    results_table.append({
        "Index Method": "FAISS HNSW (M=32, ef=64)",
        "Recall@k": np.mean(hnsw_recalls),
        "QPS": num_queries / search_time,
        "Avg Latency (ms)": (search_time / num_queries) * 1000.0,
        "Build Time (s)": build_time,
    })

    # -------------------------------------------------------------------------
    # 5. FAISS PQ (Product Quantization)
    # -------------------------------------------------------------------------
    print("\n[5/5] Benchmarking FAISS IVFPQ (nlist=100, M=8, nbits=8)...")
    quantizer_pq = faiss.IndexFlatL2(dim)
    index_pq = faiss.IndexIVFPQ(quantizer_pq, dim, num_clusters, 8, 8)
    t0 = time.perf_counter()
    index_pq.train(base)
    index_pq.add(base)
    build_time = time.perf_counter() - t0

    index_pq.nprobe = 10
    t0 = time.perf_counter()
    _, pq_I = index_pq.search(queries, k)
    search_time = time.perf_counter() - t0

    pq_recalls = [len(set(pq_I[i][:k]) & set(gt[i][:k])) / k for i in range(num_queries)]
    results_table.append({
        "Index Method": "FAISS IVFPQ (M=8, nprobe=10)",
        "Recall@k": np.mean(pq_recalls),
        "QPS": num_queries / search_time,
        "Avg Latency (ms)": (search_time / num_queries) * 1000.0,
        "Build Time (s)": build_time,
    })

    _print_summary(results_table)


def _print_summary(table: List[Dict]):
    print("\n" + "=" * 88)
    print(f"{'Index Method':<30} | {'Recall@100':<12} | {'QPS':<10} | {'Latency (ms)':<14} | {'Build (s)':<10}")
    print("-" * 88)
    for row in table:
        print(f"{row['Index Method']:<30} | {row['Recall@k']:<12.4f} | {row['QPS']:<10.1f} | {row['Avg Latency (ms)']:<14.2f} | {row['Build Time (s)']:<10.2f}")
    print("=" * 88)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="FAISS vs QUAKE Comparison Benchmark.")
    parser.add_argument("--data-dir", default=".", help="Dataset directory")
    parser.add_argument("--queries", type=int, default=500, help="Number of benchmark queries")
    parser.add_argument("--k", type=int, default=100, help="Top-k evaluation parameter")
    args = parser.parse_args()

    run_faiss_benchmark(data_dir=args.data_dir, num_queries=args.queries, k=args.k)
