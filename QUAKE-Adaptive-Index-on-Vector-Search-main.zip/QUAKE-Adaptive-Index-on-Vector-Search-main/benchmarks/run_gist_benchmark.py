"""Comprehensive GIST1M (960D) High-Dimensional Benchmark for QUAKE.

Evaluates performance on high-dimensional vectors with both Euclidean (L2)
and Cosine/Inner Product (IP) distance metrics.
"""

import argparse
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
from sklearn.cluster import KMeans

from quake.aps import scan_partitions_adaptive
from quake.distance import compute_distances, l2_normalize
from quake.io import generate_synthetic_dataset, read_fvecs, read_ivecs
from quake.maintenance import fit_latency_model, measure_centroid_overhead, run_maintenance_pass
from quake.utils import compute_recall_at_k


def run_gist_benchmark(
    data_dir: str = ".",
    num_queries: int = 1000,
    metric: str = "cosine",
    k: int = 10,
    num_clusters: int = 100,
    prob_threshold: float = 0.1,
    num_threads: int = 6,
):
    base_file = os.path.join(data_dir, "gist_base.fvecs")
    query_file = os.path.join(data_dir, "gist_query.fvecs")
    gt_file = os.path.join(data_dir, "gist_groundtruth.ivecs")

    if os.path.exists(base_file) and os.path.exists(query_file) and os.path.exists(gt_file):
        print(f"Loading GIST dataset from {data_dir}...")
        base = read_fvecs(base_file)
        queries = read_fvecs(query_file)
        gt = read_ivecs(gt_file)
    else:
        print(f"GIST files not found in {data_dir}. Generating synthetic 960D vector benchmark...")
        base, queries, gt = generate_synthetic_dataset(
            num_base=5000, num_queries=num_queries, dim=960, k=k, num_clusters=num_clusters, metric=metric, seed=42
        )

    print(f"GIST Dataset: Base={base.shape}, Queries={queries.shape}, GroundTruth={gt.shape}, Metric={metric.upper()}")

    # Normalize vectors
    X = l2_normalize(base)
    Q = l2_normalize(queries[:num_queries])

    print(f"Fitting initial {num_clusters} clusters...")
    kmeans = KMeans(n_clusters=num_clusters, random_state=42, n_init=5, verbose=0).fit(X)
    centroids = kmeans.cluster_centers_.copy()
    clusters = [X[kmeans.labels_ == i].copy() for i in range(num_clusters)]

    # Calibrate latency model
    latency_w, latency_bias = fit_latency_model(clusters, Q[:30], metric=metric)
    Oc = measure_centroid_overhead(centroids, Q[:30], metric=metric)
    print(f"Calibrated latency model: w={latency_w:.3e}, b={latency_bias:.3e}, Oc={Oc:.3e}s")

    # Threaded query runner
    from concurrent.futures import ThreadPoolExecutor
    import threading

    access_counts = np.zeros(len(clusters), dtype=np.int64)
    access_lock = threading.Lock()
    recalls = []

    def worker(q_idx, query_vec):
        neighbors, scanned, probs, scanned_indices = scan_partitions_adaptive(
            query=query_vec,
            centroids=centroids,
            clusters=clusters,
            access_counts=access_counts,
            k=k,
            prob_threshold=prob_threshold,
            metric=metric,
        )
        with access_lock:
            access_counts[scanned_indices] += 1
        return q_idx, neighbors

    print(f"\nProcessing {num_queries} queries (Metric: {metric.upper()}, Threads: {num_threads})...")
    start_time = time.perf_counter()

    with ThreadPoolExecutor(max_workers=num_threads) as executor:
        futures = [executor.submit(worker, i, Q[i]) for i in range(num_queries)]
        for f in futures:
            q_idx, neighbors = f.result()
            if len(neighbors) > 0:
                rec = compute_recall_at_k(neighbors, gt[q_idx], X, k=k)
                recalls.append(rec)

    total_time = time.perf_counter() - start_time
    avg_recall = np.mean(recalls) if recalls else 0.0
    qps = num_queries / total_time

    print("\n" + "=" * 60)
    print(f"GIST1M ({metric.upper()}) BENCHMARK RESULTS:")
    print(f"  Total Time:       {total_time:.3f}s")
    print(f"  Throughput (QPS): {qps:.1f} queries/sec")
    print(f"  Recall@{k}:        {avg_recall:.4f}")
    print("=" * 60)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run GIST1M High-Dimensional Benchmark.")
    parser.add_argument("--data-dir", default=".", help="Directory containing gist dataset files")
    parser.add_argument("--queries", type=int, default=500, help="Number of test queries")
    parser.add_argument("--metric", choices=["cosine", "L2"], default="cosine", help="Distance metric")
    parser.add_argument("--k", type=int, default=10, help="Recall@k parameter")
    parser.add_argument("--threads", type=int, default=6, help="Number of worker threads")
    args = parser.parse_args()

    run_gist_benchmark(
        data_dir=args.data_dir,
        num_queries=args.queries,
        metric=args.metric,
        k=args.k,
        num_threads=args.threads,
    )
